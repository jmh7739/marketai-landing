marketai/
├── pages/
│   ├── index.js       # 메인 페이지
│   ├── products.js    # 상품 목록 페이지
│   ├── auction.js     # 경매 페이지
│   ├── sell.js        # 판매 등록 페이지
│   ├── auth.js        # 로그인/회원가입
├── components/
│   ├── Header.js      # 헤더 (검색창 + 로그인 버튼)
│   ├── ProductCard.js # 개별 상품 카드
├── public/
│   ├── logo.png       # 로고 이미지
├── styles/
│   ├── globals.css    # 전체 스타일
├── package.json
├── README.md

